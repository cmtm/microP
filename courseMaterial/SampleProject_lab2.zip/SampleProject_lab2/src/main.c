
#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"

/* setup and initialize pins and peripherals */

/* end setup and initialize pins and peripherals */



int main()
{

	while(1) {
	}
}



